import React, {useState, useEffect} from "react";
import "./Login.css";
 

export default function Freund ({konto})

{

    const [freund, freundUpdate] = useState({});

    // *** //

 
    function readTEXTFromServer(u, cb) {

        // Anfrage an den Server scihcken
    
        window
    
          .fetch(u)
    
          // Antwort erhalten und als Text weiterreichen
    
          .then((rohdaten) => rohdaten.text())
    
          // Die weitergereichte Information an die Callback-Funktion übergeben
    
          .then((daten) => cb(daten))
    
          // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben
    
          .catch((fehler) => console.error(fehler));
    
      }
    function readJSONFromServer(u, cb) {

        // Anfrage an den Server scihcken

        window

          .fetch(u)

          // Antwort erhalten und als JSON-Objekt weiterreichen

          .then((rohdaten) => rohdaten.json())

          // Die weitergereichte Information an die Callback-Funktion übergeben

          .then((daten) => cb(daten))

          // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

          .catch((fehler) => console.error(fehler));

      }

   

    // *** //

    useEffect(

        () => {

            readJSONFromServer(

                "http://localhost:8088/freundinfo/" + konto,

                (antwort) => {

                    freundUpdate(antwort);

                }

            );

        },

        [konto]

    );
    function verwerfen(aNr)

    {
       
  
      readTEXTFromServer(
  
        "http://localhost:8088/freund/entf/" +aNr+ "/" +
  
        freund ,
  
        (e)=>
  
        {
            freundUpdate([...freund, []]);
           
        }
  
      );
  
    }
    

    // *** //

    return (

        <>

            <table className = "abwechselndeTabellenZeilen">

                <tr>

                    <th>Vorname</th>

                    <th>Nachname</th>

                    <th rowSpan={2}> <button onClick={()=>verwerfen()}>Verwerfen</button></th>

                </tr>

                <tr>

                    <td>{freund.Vorname}</td>

                    <td>{freund.Nachname}</td>

                 

                </tr>

            </table>

            <hr />

        </>

    );

}