import React, { useEffect, useState } from "react";

import Freund from "./Freund";

 

export default function Freunde() {

  const [freunde, freundeUpdate] = useState([]);

  // *** //

  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

  // *** //

  useEffect(() => {

    let meinKonto = JSON.parse(localStorage.getItem("benutzer")).kontoNr;

    // *** //

    readJSONFromServer(

      "http://localhost:8088/freunde/auflisten/" + meinKonto,

      (antwort) => {

        const daten = [];

        // *** //

        console.log(antwort);

        antwort.forEach((zeile) =>

          daten.push(<Freund konto={zeile.FreundKontoNr} />)

        );

        // *** //

        freundeUpdate(daten);

      }

    );

  }, []);

  // ***  //

  return <>

    {freunde}

  </>;

}