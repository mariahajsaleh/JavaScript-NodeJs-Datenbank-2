import React, {useEffect, useState} from "react";

import Login from "./Login";

 

export default function Oops() {

  const [erneutLogin, erneutLoginLaden] = useState();

  // *** //

  useEffect(

    () => {

        localStorage.setItem("eingeloggt", "0");

        erneutLoginLaden(<Login />);

    }, []

  );

  // *** //

  return (

    <>

      <h3>Oops, es ist was schiefgelaufen</h3>;

      <p>BenutzerName oder Kennwort flasch</p>

      <hr />

      {erneutLogin}

    </>

  );

}