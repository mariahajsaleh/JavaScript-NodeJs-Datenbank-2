import { Link, Outlet } from "react-router-dom";

import React, {useEffect, useState} from "react";

import Login from "./Login.js";

import "./Menu.css";

 

export default function Menu()

{const [zustand,zustandUpdate] = useState(0);

    // *** //

    useEffect(

        () => {

            window.setInterval(

                () => {

                    zustandUpdate(Number(localStorage.getItem("eingeloggt")));

                },

                250

            );

        },

        []

    );

    // *** //

    return (

        <>

        {Number(localStorage.getItem("eingeloggt")) === NaN ||

         Number(localStorage.getItem("eingeloggt")) === 0 ?

        <Login /> :

        <>

            {zustand === 1 ?

            <header>

                <Link to="/">Meine Daten</Link>

                <Link to="/blog">Mein Blog</Link>

                <Link to="/finden">Freunde finden</Link>

                <Link to="/freunde">Meine Freunde</Link>

                <Link to="/logout"><b>Abmelden</b></Link>

            </header>

            :

            <></>

            }

            <hr />

            <main>

                <Outlet />

            </main>

        </>

        }

        </>

    );

}