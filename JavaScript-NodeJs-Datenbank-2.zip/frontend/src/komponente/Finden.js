import React, {useState} from "react";

 

export default function Finden() {

  const [freundeFinden, freundeFindenUpdate] = useState([]);

 

  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

 

  function annehmen(meinKontoNr, freundKontoNr)

  {

    // /freundschaft/:k1/:k2

   

    readTEXTFromServer(

      "http://localhost:8088/freundschaft/" +

      meinKontoNr + "/" +

      freundKontoNr,

       (e)=>

       {}

    );

  };

 

 

  function verwerfen(meinKontoNr, freundKontoNr)

  {

    readTEXTFromServer(

      "http://localhost:8088/freund/entf/" +

      meinKontoNr + "/" +

      freundKontoNr,

      (e)=>

      {}

    );

  }

 

  function suchen(begriff)

  {

    let meinKonto = JSON.parse(localStorage.getItem("benutzer")).kontoNr;

    // *** //

    readJSONFromServer(

      "http://localhost:8088/freunde/finden/" + meinKonto + "/" + begriff,

      (antwort) => {

        const daten = [];

        // *** //

        antwort.forEach(

          (zeile) => {

            daten.push(

              <div>

                <p>{zeile.Vorname} {zeile.Nachname}</p>

              

                <button onClick={()=>annehmen(meinKonto, zeile.KontoNr)}>Annehmen</button>

                <button onClick={()=>verwerfen(meinKonto, zeile.KontoNr)}>Verwerfen</button>

              </div>

            );

          }

        );

        // *** //

        freundeFindenUpdate(daten);

      }

    );

  }

 

  return (

    <>

    <input type = "text" placeholder = "Freunde finden..." onKeyUp={(e) => suchen(e.target.value)} />

    <hr />

    <ul>{freundeFinden}</ul>

    </>

  );

}