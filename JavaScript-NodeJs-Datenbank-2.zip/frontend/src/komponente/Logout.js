import React, {useEffect} from "react";

 

export default function Logout()

{

    useEffect(

        () => {

            localStorage.removeItem("eingeloggt");

            window.setTimeout(

                () => {

                    window.location.href = "http://localhost:3000/";

                },

                1000

            );

        },

        []

    );

    // *** //

    return (

        <>

            <h3>Du bist ausgeloggt</h3>

            <p>Danke für deinen Besuch. Bis dann :-)</p>

        </>

    )

}