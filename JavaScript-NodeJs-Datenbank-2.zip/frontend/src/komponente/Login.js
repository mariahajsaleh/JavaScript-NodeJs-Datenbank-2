import React, { useState } from "react";

import "./Login.css";

import Willkommen from "./Willkommen";

import Oops from "./Oops";

import Menu from "./Menu";

 

export default function Login() {

  const [loginBenutzer, loginBenutzerUpdate] = useState("");

  const [loginKennwort, loginKennwortUpdate] = useState("");

  // *** //

  const [regVorname, regVornameUpdate] = useState("");

  const [regNachname, regNachnameUpdate] = useState("");

  const [regBenutzer, regBenutzerUpdate] = useState("");

  const [regKennwort, regKennwortUpdate] = useState("");

  // *** //

  const [ergebnis, ergebnisUpdate] = useState("");

  // *** //

  const [loginInfo, loginInfoUpdate] = useState({});

  // *** //

  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

  // *** //

  const einloggen = () => {

    // /login/:name/:pass

    readTEXTFromServer(

      "http://localhost:8088/login/" + loginBenutzer + "/" + loginKennwort,

      (antwort) => {

        localStorage.setItem("eingeloggt", antwort === "0" ? "0" : "1");

        localStorage.setItem(

          "benutzer",

          JSON.stringify({

            Benutzer: loginBenutzer,

            Kennwort: loginKennwort,

            kontoNr: antwort,

          })

        );

        ergebnisUpdate(antwort);

        if (antwort != "0")

          loginInfoUpdate({

            Benutzer: loginBenutzer,

            Kennwort: loginKennwort,

          });

      }

    );

  };

  // *** //

  const registrieren = () => {

    const objekt = {

      Vorname: regVorname,

      Nachname: regNachname,

      Benutzer: regBenutzer,

      Kennwort: regKennwort,

    };

    // *** //

    if (regVorname == "") alert("Bitte Vorname eintippen!");

    else if (regNachname == "") alert("Bitte Nachname eintippen!");

    else if (regBenutzer == "") alert("Bitte Benutzer eintippen!");

    else if (regKennwort == "") alert("Bitte Kennwort eintippen");

    else

      readTEXTFromServer(

        "http://localhost:8088/registrieren/" + JSON.stringify(objekt),

        (e) => {

          regVornameUpdate("");

          regNachnameUpdate("");

          regBenutzerUpdate("");

          regKennwortUpdate("");

          // *** //

          const feld = document.getElementsByTagName("input");

          // *** //

          for (let f = 2; f < feld.length; f++) feld[f].value = "";

        }

      );

  };

  // *** //

  return (

    <>

      {ergebnis === "" || ergebnis === "0" ? (

        <>

          <div className="formularKasten">

            <h3>Einloggen</h3>

            <input

              type="text"

              placeholder="Benutzer"

              onKeyUp={(e) => loginBenutzerUpdate(e.target.value)}

            />

            <br />

            <input

              type="password"

              placeholder="Kennwort"

              onKeyUp={(e) => loginKennwortUpdate(e.target.value)}

            />

            <br />

            <button onClick={einloggen}>Anmelden</button>

          </div>

          <div className="formularKasten">

            <h3>Registrieren</h3>

            <input

              type="text"

              placeholder="Vorname"

              onKeyUp={(e) => regVornameUpdate(e.target.value)}

            />

            <br />

            <input

              type="text"

              placeholder="Nachname"

              onKeyUp={(e) => regNachnameUpdate(e.target.value)}

            />

            <br />

            <input

              type="text"

              placeholder="Benutzer"

              onKeyUp={(e) => regBenutzerUpdate(e.target.value)}

            />

            <br />

            <input

              type="password"

              placeholder="Kennwort"

              onKeyUp={(e) => regKennwortUpdate(e.target.value)}

            />

            <br />

            <button onClick={registrieren}>Registrieren</button>

          </div>

        </>

      ) : (

        <>

          <Menu />

        </>

      )}

      {ergebnis === "0" ? <Oops /> : <></>}

    </>

  );

}