import React, { useState, useEffect } from "react";

 

export default function Willkommen() {

  const [daten, datenUpdate] = useState({});

  const [meinBlog, meinBlogUpdate] = useState([]);

  // *** //

  const [loginBenutzer, loginBenutzerUpdate] = useState("");

  const [loginKennwort, loginKennwortUpdate] = useState("");

  const [regVorname, regVornameUpdate] = useState("");

  const [regNachname, regNachnameUpdate] = useState("");

  const [regTelefon, regTelefonUpdate] = useState("");

  const [regEmail, regEmailUpdate] = useState("");

  const [regAdresse, regAdresseUpdate] = useState("");

  const [regPLZ, regPLZUpdate] = useState("");

  const [regOrt, regOrtUpdate] = useState("");

  // *** //

  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

  // *** //

  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

  const blogAktualisieren = (KontoNummer) => {

    readJSONFromServer(

      "http://localhost:8088/blog/letzte3abrufen/" + KontoNummer,

      (antwort) => {

        const daten = [];

        // *** //

        antwort.forEach(

          (zeile) => {

            daten.push(

              <>

              <div>

                <h3>{zeile.Titel}</h3>

                <p>{zeile.Text}</p>

                <hr />

              </div>

              </>

            )

          }

        );

        // *** //

        meinBlogUpdate(daten);

      }

    );

  }

 

  // *** //

  useEffect(() => {

    let benutzerDaten = localStorage.getItem("benutzer");

    // *** //

    let BenutzerName = "";

    let BenutzerKennwort = "";

    // *** //

    if (typeof benutzerDaten === "string" && benutzerDaten != "")

    {

      switch(benutzerDaten[0])

      {

        case '[': case '{':

          benutzerDaten = JSON.parse(benutzerDaten);

          BenutzerName = benutzerDaten.Benutzer;

          BenutzerKennwort = benutzerDaten.Kennwort;

          break;

        default:

          benutzerDaten = {};

          break;

      }

    }

    // *** //

    readJSONFromServer(

      "http://localhost:8088/datenlesen/" +

        JSON.stringify({

          Benutzer: BenutzerName,

          Kennwort: BenutzerKennwort,

        }),

      (antwort) => {

        console.log(antwort);

        if (antwort.length > 0) {

            datenUpdate(antwort[0]);

            loginBenutzerUpdate(antwort[0].Benutzer);

            loginKennwortUpdate(antwort[0].Kennwort);

            regVornameUpdate(antwort[0].Vorname);

            regNachnameUpdate(antwort[0].Nachname);

            regTelefonUpdate(antwort[0].Telefon);

            regEmailUpdate(antwort[0].Email);

            regAdresseUpdate(antwort[0].Adresse);

            regPLZUpdate(antwort[0].PLZ);

            regOrtUpdate(antwort[0].Ort);

            // *** //

            blogAktualisieren(antwort[0].KontoNr);

        }

      }

    );

  }, []);

  // *** //

  function Aendern(kontoNummer){

    const objekt = {

        KontoNr : kontoNummer,

        Benutzer : loginBenutzer,

        Kennwort : loginKennwort,

        Vorname : regVorname,

        Nachname : regNachname ,

        Telefon : regTelefon ,

        Email : regEmail ,

        Adresse : regAdresse ,

        PLZ : regPLZ ,

        Ort : regOrt

    };

    // *** //

    readTEXTFromServer(

        "http://localhost:8088/datenschreiben/" + JSON.stringify(objekt),

        (antwort) => {}

    );

  }

  // *** //

  return (

    <>

      <h3>Meine Daten</h3>

      <input

        type="text"

        defaultValue={daten.Benutzer}

        placeholder="Benutzer..."

        onKeyUp={(e) => loginBenutzerUpdate(e.target.value)}

      />

      <input

        type="text"

        defaultValue={daten.Kennwort}

        placeholder="Kennwort..."

        onKeyUp={(e) =>loginKennwortUpdate(e.target.value)}

      />

      <input

        type="text"

        defaultValue={daten.Vorname}

        placeholder="Vorname..."

        onKeyUp={(e) => regVornameUpdate(e.target.value)}

      />

      <input

        type="text"

        defaultValue={daten.Nachname}

        placeholder="Nachname..."

        onKeyUp={(e) => regNachnameUpdate(e.target.value)}

      />

      <input

        type="number"

        defaultValue={daten.Telefon}

        placeholder="Telefon..."

        onKeyUp={(e) =>regTelefonUpdate(e.target.value)}

      />

      <input

        type="text"

        defaultValue={daten.Email}

        placeholder="Email..."

        onKeyUp={(e) =>  regEmailUpdate(e.target.value)}

      />

      <input

        type="text"

        defaultValue={daten.Adresse}

        placeholder="Adresse..."

        onKeyUp={(e) => regAdresseUpdate(e.target.value)}

      />

       <input

        type="number"

        defaultValue={daten.PLZ}

        placeholder="PLZ..."

        onKeyUp={(e) =>regPLZUpdate(e.target.value)}

      />

       <input

        type="text"

        defaultValue={daten.Ort}

        placeholder="Ort..."

        onKeyUp={(e) =>  regOrtUpdate(e.target.value)}

      />

       <button onClick={()=>Aendern(daten.KontoNr)}>Ändern</button>

       

       <hr/>

       {meinBlog}

    </>

  );

}