import React, {useEffect, useState} from "react";

export default function Blog() {

  const [meinBlog, meinBlogUpdate] = useState([]);

  const [meinKonto, meinKontoUpdate] = useState(undefined);

  const [neueTitel, neueTitelUpdate] = useState("");

  const [neuerText, neuerTextUpdate] = useState("");

 
  function readJSONFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als JSON-Objekt weiterreichen

      .then((rohdaten) => rohdaten.json())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

  function readTEXTFromServer(u, cb) {

    // Anfrage an den Server scihcken

    window

      .fetch(u)

      // Antwort erhalten und als Text weiterreichen

      .then((rohdaten) => rohdaten.text())

      // Die weitergereichte Information an die Callback-Funktion übergeben

      .then((daten) => cb(daten))

      // Falls ein Fehler aufteten sollte, diese auf der Konsole ausgegeben

      .catch((fehler) => console.error(fehler));

  }

 

  const blogAktualisieren = (KontoNummer) => {

    readJSONFromServer(

      "http://localhost:8088/blog/abrufen/" + KontoNummer,

      (antwort) => {

        const daten = [];

        // *** //

        antwort.forEach(

          (zeile) => {

            daten.push(

              <>

              <div>

                <h3>{zeile.Titel}</h3>

                <p>{zeile.Text}</p>

                <button onClick={()=>entfernen(zeile.id)}>Entfernen</button>

                <button onClick={()=>bearbeiten(zeile.id)}>Ändern</button>

              </div>

              <hr />

              </>

            )

          }

        );

        // *** //

        meinBlogUpdate(daten);

      }

    );

  }

 

  useEffect(

    () => {

      let KontoNummer = JSON.parse(localStorage.getItem("benutzer")).kontoNr;

      // *** //

      meinKontoUpdate(KontoNummer);

      // *** //

      blogAktualisieren(KontoNummer);

    },

    []

  );

 

  const entfernen=(blogId)=>{

    readTEXTFromServer(

      "http://localhost:8088/blog/entf/" +

       blogId,

       (e)=>

       {

        blogAktualisieren(meinKonto);

       }

    );

  };

 

  const bearbeiten=(blogId)=>{

    let titel = prompt("Gib eine neue Titel:");

    let text = prompt("Gib eine neue Text:");

    readTEXTFromServer(

      "http://localhost:8088/blog/edit/" +

       blogId + "/" +

       titel + "/" +

       text,

       (e)=>

       {

        blogAktualisieren(meinKonto);

       }

    );

  };

   

  const neuerBlogEintrag=(KontoNr)=>{

    readTEXTFromServer(

      "http://localhost:8088/blog/erstellen/" +

       KontoNr + "/" +

       neueTitel + "/" +

       neuerText,

       (e)=>

       {

        neueTitelUpdate("");

        neuerTextUpdate("");

        blogAktualisieren(KontoNr);

        //

        const feld1 = document.getElementsByTagName("input")[0];

        //

        feld1.value = "";

        //

        const feld2 = document.getElementsByTagName("textarea")[0];

        //

        feld2.value = "";

       }

    );

  };

 

  return (

    <>

    <h3>Blog</h3>

    <hr />

    {meinBlog}

    <hr />

    <h3>neuer blog eintrag</h3>

    <input type = "text" placeholder = "Titel" onKeyUp={(e) => neueTitelUpdate(e.target.value)} />

    <br />

    <textarea placeholder = "Text" onKeyUp={(e) => neuerTextUpdate(e.target.value)} />

    <br />

    <button onClick={() => neuerBlogEintrag(meinKonto)}>Erstellen</button>

    </>

  );

}