import logo from './logo.svg';
import './App.css';
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Menu from './komponente/Menu';
import Login from './komponente/Login';
import Willkommen from './komponente/Willkommen';
import Blog from "./komponente/Blog";
import Finden from './komponente/Finden';
import Freunde from './komponente/Freunde';
import Logout from './komponente/Logout';

function App() {
  return (

    <>

      <BrowserRouter>

        <Routes>

          <Route path="/" element={<Menu />}>

            <Route index element={<Willkommen />} />

            <Route path="/blog" element={<Blog />} />

            <Route path="/finden" element={<Finden />} />

            < Route path="/freunde" element={<Freunde />} />

            <Route path="/logout" element={<Logout />} />

          </Route>

        </Routes>

      </BrowserRouter>

    </>

  );
}

export default App;
