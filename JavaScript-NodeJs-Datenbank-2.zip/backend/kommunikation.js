const express = require("express");

const app = express();
const cors = require("cors"); // Cors ist eine Funktion

app.use(cors());

const sqlite3 = require("sqlite3");

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

 * Verbindung zum Datenbank-Datei aufbauen

 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

 

let db = new sqlite3.Database("./datenBestand.db", (fehler) => {

  if (fehler) console.error(fehler.message);

  else

    console.log("Verbindung zum Datenbank test.db erfolgreich aufgebaut :-)");

});


const PortNummer = 8088;

app.get("/freundinfo/:konto", (req, res) => {

  db.all(

    `SELECT * FROM BenutzerKonto WHERE KontoNr = '${req.params.konto}'`,

    (fehler, zeilen) => {

      res.send(JSON.stringify(zeilen[0]));

    }

  );

});

app.get("/login/:name/:pass", (req, res) => {

  db.all(

    `SELECT * FROM BenutzerKonto WHERE Benutzer = '${req.params.name}' AND Kennwort = '${req.params.pass}'`,

    (fehler, zeilen) => {

      let antwort = zeilen.length > 0 ? zeilen[0].KontoNr : "0";

      res.send(antwort.toString());

    }

  );

});

app.get("/logout", (req, res) => {

  res.send("logout");

});

 

app.get("/datenlesen/:objekt", (req, res) => {

  const o = JSON.parse(req.params.objekt);

  if (

    o !== null &&

    typeof o === "object" &&

    o.Benutzer !== undefined &&

    o.Kennwort !== undefined

  ) {

    console.log(o);

    db.all(

      `SELECT * FROM BenutzerKonto WHERE

          Benutzer = '${o.Benutzer}' AND

          Kennwort = '${o.Kennwort}' LIMIT 1`,

      (fehler, zeilen) => {

        res.send(JSON.stringify(zeilen));

      }

    );

  } else res.send(JSON.stringify([{}]));

});

 

app.get("/datenschreiben/:objekt", (req, res) => {

  const o = JSON.parse(req.params.objekt);

  if (

    o !== null &&

    typeof o === "object"

  )

  db.run(

    `UPDATE BenutzerKonto SET

    Benutzer = '${o.Benutzer}',

    Kennwort = '${o.Kennwort}',

    Vorname = '${o.Vorname}',

    Nachname= '${o.Nachname}',

    Telefon= '${o.Telefon}',

    Email = '${o.Email}',

    Adresse = '${o.Adresse}',

    PLZ= '${o.PLZ}',

    Ort = '${o.Ort}'

     WHERE KontoNr = ${o.KontoNr}`,

    (fehler) => console.error(fehler)

  );

});

app.get("/registrieren/:objekt", (req, res) => {

  const o = JSON.parse(req.params.objekt);

  if (o !== null)

    db.run(

      `INSERT INTO BenutzerKonto

    ( Benutzer, Kennwort, Vorname, Nachname )

    VALUES

    ( '${o.Benutzer}',

      '${o.Kennwort}',

      '${o.Vorname}',

      '${o.Nachname}' )`,

      (fehler) => console.error(fehler)

    );

  res.send("ok");

});
app.get("/blog/letzte3abrufen/:konto", (req, res) => {

 // ASC oder DESC?

  const k = req.params.konto;

  db.all(

    `SELECT * FROM BlogDaten WHERE KontoNr = '${k}' ORDER BY id DESC LIMIT 3`,

    (fehler,zeilen) => {

      res.send(JSON.stringify(zeilen));

    }

  );

});

 

app.get("/blog/abrufen/:konto", (req, res) => {
 const k = req.params.konto;

    db.all(

      `SELECT * FROM BlogDaten WHERE KontoNr = '${k}'`,

      (fehler,zeilen) => {

        res.send(JSON.stringify(zeilen));

      }

    );

});

app.get("/blog/erstellen/:konto/:titel/:text", (req, res) => {

  const o = req.params;

  db.run(  `INSERT INTO  BlogDaten  ( KontoNr, Titel, Text )

    VALUES

    ( '${o.konto}', '${o.titel}', '${o.text}' )`,

     

      (fehler) => console.error(fehler)

    );

  res.send("ok");

});

app.get("/blog/edit/:dnr/:titel/:text", (req, res) => {

    const o = req.params;

  db.run(

    `UPDATE BlogDaten SET

    Titel = '${o.titel}',

    Text = '${o.text}'

     WHERE id = ${o.dnr}`,

    (fehler) => console.error(fehler)

  );

 

  res.send("OK");

});


app.get("/blog/entf/:dnr", (req, res) => {

  db.all(

    ` DELETE FROM BlogDaten WHERE id ='${dnr}'`,

    );
   res.send("ok");

});

app.get("/freunde/finden/:konto/:begriff", (req, res) => {

  let b = req.params.begriff;

  let k = req.params.konto;

  db.all(

    `SELECT * FROM BenutzerKonto WHERE (

    Vorname LIKE '%${b}' OR Vorname LIKE '%${b}%' OR Vorname LIKE '${b}%' OR

    Nachname LIKE '%${b}' OR Nachname LIKE '%${b}%' OR Nachname LIKE '${b}%' OR

    Email LIKE '%${b}' OR Email LIKE '%${b}%' OR Email LIKE '${b}%' ) AND KontoNr <> '${k}'`,

    (fehler, zeilen) => {

      console.log(zeilen);

      res.send(JSON.stringify(zeilen));

    }

  );

});

app.get("/freundschaft/:k1/:k2", (req, res) => {

  db.all(

    `INSERT INTO Freunde

    ( KontoNr, FreundKontoNr )

    VALUES

    ( '${req.params.k1}', '${req.params.k2}' )`,

    (fehler, zeilen) => {

      res.send("ok");

    }

  );

});

app.get("/freund/entf/:k1/:k2", (req, res) => {

  db.all(

    ` DELETE FROM Freunde WHERE  

    KontoNr ='${req.params.k1}' AND FreundKontoN = '${req.params.k2}'`,

    (fehler, zeilen) => {

      res.send("OK");

    }

  );

});

app.get("/freunde/auflisten/:konto", (req, res) => {

  db.all(

    `SELECT * FROM freunde WHERE  KontoNr = '${req.params.konto}'`,

    (fehler, zeilen) => {

      res.send(JSON.stringify(zeilen));

    }

  );

});

 

/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *

 * Der eigentliche Server ist ein Unterprogramm der ständig den angegebenen Port überprüft,

 * und schaut, ob eine Anfrage (request) angekommen ist. Wenn ja, wird die Anfrage an

 * die Routen weitergeleitet.

 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

const server = app.listen(

  PortNummer, // Die Portnummer, die abgehört werden soll

  () =>

    // Die Callback-Funktion, die aufgerufen wird, wenn was reinkommt

    {

      // Beispiel auf Konsole

      console.log(`Server horcht nach http://localhost:${PortNummer}/`);

    }

);

 
